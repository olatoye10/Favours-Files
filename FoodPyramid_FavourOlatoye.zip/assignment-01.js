var num1 = 0;
    var num2 = 0;
    var num3 = 0;
    var num4 = 0;
    var num5 = 0;
    var num6 = 0;


    function decreaseValue(set) {
        if (set === 1){
            num1--;
			if(num1<0)
			{
				num1=0;
			}
            document.getElementById("num1").innerHTML = num1;
        }
		else if (set === 2)
		{
            num2--;
			if(num2<0)
			{
				num2=0;
			}
            document.getElementById("num2").innerHTML = num2;
        }
		else if (set === 3){
            num3--;
			if(num3<0)
			{
				num3=0;
			}
            document.getElementById("num3").innerHTML = num3;
        }
		else if (set === 4){
            num4--;
			if(num4<0)
			{
				num4=0;
			}
            document.getElementById("num4").innerHTML = num4;
        }
		else if (set === 5){
            num5--;
			if(num5<0)
			{
				num5=0;
			}
            document.getElementById("num5").innerHTML = num5;
        }
		else if (set === 6){
            num6--;
			if(num6<0)
			{
				num6=0;
			}
            document.getElementById("num6").innerHTML = num6;
        }

    }

    function increaseValue(set) {
        if (set === 1){
            num1++;
            document.getElementById("num1").innerHTML = num1;
        }
		else if (set === 2){
            num2++;
            document.getElementById("num2").innerHTML = num2;
        }
        else if (set === 3){
            num3++;
            document.getElementById("num3").innerHTML = num3;
        }
        else if (set === 4){
            num4++;
            document.getElementById("num4").innerHTML = num4;
        }
		else if (set === 5)
		{
            num5++;
            document.getElementById("num5").innerHTML = num5;
        }
		else if (set === 6)
		{
            num6++;
            document.getElementById("num6").innerHTML = num6;
        }
    } 

	