let started = false;// checks if user has started a new round
let level = 0; //before round is started
let signal = []; //array that holds the signal user has to copy
let buttons = ["green", "red", "yellow", "blue"]; // array of all possible buttons
let currentScore = 0; 
let highScore = 0;

function startGame(){ // user has pressed start button to start new round
    if(!started){ // if round hasnt started
        document.getElementById('indicator').style.backgroundColor = "green"; // turn indicator to green
        started = 'true'; // round has started
        setTimeout(newLevel, 3000); // start a new level after 3 seconds
    }    
}

function newLevel(){ 
    level++; //level increases
    let randButton = Math.floor(Math.random()*4); // choose random number from 0-3
    let randBtn = buttons[randButton]; //random number choses a button from the button array
    let nextButton=document.querySelector(`.${randBtn}`); //the element matching that button is selected as the next button
    signal.push(nextButton); // the next button is added to signal array
    signalFlash(signal); // the signal is then flashed and shown to the player
    //startTimer();
    playerSignals(); // players turn to copy signal
}

/*function startTimer(){
    let timer = setTimeout(function() {
        playerLost();
    }, 5000); // Set timer to 5 seconds
}*/

function playerSignals(){
   //let win = false; //checks if player has won level

   /*const timer = setTimeout(function() { //makes timer, issues implementing this as it only works for first 2 levels sbut game works 100% if timer commented out
      playerLost(); //player loses and timer is removed
      clearTimeout(timer);
    }, 5000);//sets timer to 5 seconds*/

    let currentIndex = 0; //keeps track of what button in the signal is being copied as sigbal array is searched
    const clickHandler = function(event) { //checks if the user is clicking the correct buttons
        let pressed = event.target; //the element that has been clicked is 'pressed'
        if (pressed.classList.contains('green') || pressed.classList.contains('red') || pressed.classList.contains('yellow') || pressed.classList.contains('blue')) { //makes sure user clicks one of the 4 colour buttons
            flash(pressed); // flashes button that has been clicked
            if (pressed===signal[currentIndex]) { //if the clicked button matches the signal
                currentIndex++; // then moves onto the next item in the signal
                if (currentIndex === signal.length) { //if end of signal is reached without any mistake
                    //win = true; //player has won round
                    //clearTimeout(timer); //end timer
                    document.removeEventListener('click', clickHandler); //stop checking for clicks
                    currentScore++; // add score
                    changeScore(currentScore) //change score on screen
                    setTimeout(newLevel, 1000); // start new round after 1 second
                }
            } else { //if player failed to match an item in the signal
                playerLost(); //they lose
                //clearTimeout(timer); //end timer
                //win = false; //has not won
                document.removeEventListener('click', clickHandler);//stop checking for clicks
            }
        }
    };
    document.addEventListener('click', clickHandler);//check for clicks for every item in signal
}

//following functions change scores on the screen
function changeScore(currentScore){ 
    if(currentScore<10){
        document.querySelector('.currentScore').innerText = "0" + currentScore;
    }
    else{
        document.querySelector('.currentScore').innerText = currentScore;
    }
}
function changeHScore(highScore){
    if(highScore<10){
        document.querySelector('.highScore').innerText = "0" + highScore;
    }
    else{
        document.querySelector('.highScore').innerText = highScore;
    }
}


function flash(col) { //takes in a button to flash
        col.style.backgroundImage = "linear-gradient(#ffffc634, #aeaeae7f)";
        col.style.backgroundColor = "white";
        setTimeout(function() {
            col.style.backgroundImage = "";
            col.style.backgroundColor = "";
             // Reset to original color after 0.2 seconds
        }, 200);    
}

function signalFlash(array){ // flashes the signal for the user
   if(started=='true'){ // if the round hasnt ended
    let interval = 1200; //flashes every second
   if(level>4){ //on 5th signal
    interval = 700 //flashes every .5 seconds
   }
   else if(level>8){ //on 9th signal
    interval = 400 //flashes every .4 seconds
   }
   else if(level>12){ //on 13th signal
    interval = 200 //flashes every .2 seconds
   }

   for(let i=0; i<array.length; i++){
    setTimeout(()=>flash(array[i]), i*interval); //flashes every button in the array based on intervals described above
   }
   }
   
}


function playerLost(){
    document.getElementById('indicator').style.backgroundColor = "red"; //turn indicator back to red
    for(let i=0; i<5; i++) //flashes all buttons 5 times
    {
       setTimeout(function(){
        flash(document.querySelector('.red'));
        flash(document.querySelector('.green'));
        flash(document.querySelector('.yellow'));
        flash(document.querySelector('.blue'));
       }, 300*i); //with .3 seconds between each flash
    }
    //resets game controls
    started = false;
    signal = [];
    level = 0;
    if(currentScore>highScore) //changes high score if its been beaten
    {
        highScore=currentScore;
        changeHScore(highScore);
    }
    currentScore = 0; //resets current score
    changeScore(currentScore);
    
}

