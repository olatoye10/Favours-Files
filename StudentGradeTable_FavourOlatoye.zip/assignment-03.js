const tableRows = document.querySelectorAll('tr');


function getUnsubmitted(){
  let unsubmitted = 0;
  var grades = document.getElementsByClassName("toMiddle");  //loop through all grades
  for(var i = 0, j = grades.length; i < j; ++i) {
  grades[i].style.backgroundColor = "yellow"; // change their background colour to yellow if theyre still unsubmitted 
  }

  var tds = document.getElementsByTagName("td");  //loop through all data and if theyre yellow then add to unsubmitted
  for(var i = 0, j = tds.length; i < j; ++i) {
    if(tds[i].style.backgroundColor === "yellow")
    {
      unsubmitted++;
    }
  }

  let unsub = unsubmitted.toString(10); // change to a string so i can add it to the <p>
  document.getElementById("text").innerHTML = unsub + ' Assignments Unsubmitted'; 
  updateAverage();
}


function changeGrade(cell)
{ 
 
  const grade = Number(cell.textContent, 10); //change new input to number

  if (isNaN(grade) || grade < 1 || grade > 100) { // if its not a valid grade
    setTimeout(() => {
      cell.textContent = "-";
      cell.style.textAlign = "center";
      cell.style.backgroundColor = "yellow"; // change its style accordingly
    },1000);
    
    getUnsubmitted(); 
    return;
  }
  //if it is a valid grade
  cell.style.textAlign = "right";
  cell.classList.remove("toMiddle");
  cell.style.backgroundColor = "";
  getUnsubmitted();
  updateAverage(); //get average as it has now changed
}


function updateAverage()
{
   
  var table = document.getElementById("myTable"); //get table

  
  for (var i = 1; i < table.rows.length; i++) {//loop through each row bar headers
    var row = table.rows[i];
    var sum = 0;
    var count = 0;

    
    for (var j = 0; j < row.cells.length - 1; j++) { //loop through each cell in the row
      
      var cellValue = Number(row.cells[j].innerText); //change to number 
      if (!isNaN(cellValue) && cellValue != '' && cellValue<101) { // if its a valid number
        sum += cellValue; // add to sum of row
        count++; // add to amount of submitted assignments in row
      }
    }
    let avg = sum/count; //average is sum of grades over amount of submitted assignments
    if(!isNaN(avg)) // make sure the average is valid
    {
      row.cells[row.cells.length - 1].innerText = Math.round(avg); // round it to whole num and change average cell of the row
      if(avg<60) //change style accordingly if less than 60
      {
        row.cells[row.cells.length - 1].style.backgroundColor = "red";
        row.cells[row.cells.length - 1].style.color = "white";
      }
      else{
        row.cells[row.cells.length - 1].style.backgroundColor = "";
        row.cells[row.cells.length - 1].style.color = "";
      }
    }
    else{ // if its not a valid number
      row.cells[row.cells.length - 1].innerText = '0'; // no average
    }
  }
   if(toggle === 1 || toggle === 2) //checks what state the average column is in
   {
    toggle = 0; // so it shows numerical value
    toggleAverage();
   }
}

let toggle = 1; //starts toggle in second state
function toggleAverage()
{
  let row = document.getElementsByTagName('th');
  let headCell = row[row.length-1];
  //toggles between the three numbers changing states of avg column
  if(toggle === 0)
  {
    headCell.textContent = 'Average (%)';
    toggle = 1;
    updateAverage();
  }
  else if(toggle === 1)
  {
    headCell.textContent = 'Average (Letter)';
    toggle = 2;
    changeToLetter();
    
  }
  else
  {
    headCell.textContent = 'Average (4.0)';
    toggle = 0;
    changeToGpa();
  }
}

function changeToLetter() { //changes all averages to Letter value
  var table = document.getElementById("myTable");

  
  for (var i = 1; i < table.rows.length; i++) { // Loop through each row in the table bar header
    var row = table.rows[i];

    
    var avgCell = row.cells[row.cells.length - 1];// Get the last cell in the current row

    
    var cellValue = Number(avgCell.innerText, 10); //changes to number then makes sure its valid
    if(!isNaN(cellValue) && cellValue<60 )// Change the value of the last cell accordingly
    {
      avgCell.innerText = 'F';
    }
    if(!isNaN(cellValue) && cellValue>59 && cellValue<63 )
    {
      avgCell.innerText = 'D-';
    }
    if(!isNaN(cellValue) && cellValue>62 && cellValue<67 )
    {
      avgCell.innerText = 'D';
    }
    if(!isNaN(cellValue) && cellValue>66 && cellValue<70 )
    {
      avgCell.innerText = 'D+';
    }
    if(!isNaN(cellValue) && cellValue>69 && cellValue<73 )
    {
      avgCell.innerText = 'C-';
    }
    if(!isNaN(cellValue) && cellValue>72 && cellValue<77 )
    {
      avgCell.innerText = 'C';
    }
    if(!isNaN(cellValue) && cellValue>76 && cellValue<80)
    {
      avgCell.innerText = 'C+';
    }
    if(!isNaN(cellValue) && cellValue>79 && cellValue<83 )
    {
      avgCell.innerText = 'B-';
    }
    if(!isNaN(cellValue) && cellValue>82 && cellValue<87 )
    {
      avgCell.innerText = 'B';
    }
    if(!isNaN(cellValue) && cellValue>86 && cellValue<90 )
    {
      avgCell.innerText = 'B+';
    }
    if(!isNaN(cellValue) && cellValue>89 && cellValue<93  )
    {
      avgCell.innerText = 'A-';
    }
    if(!isNaN(cellValue) && cellValue>92 && cellValue<101)
    {
      avgCell.innerText = 'A';
    }


  }
}

function changeToGpa() // changes averages to 4.0 format
{
  var table = document.getElementById("myTable");

  
  for (var i = 1; i < table.rows.length; i++) {
    var row = table.rows[i];

    
    var avgCell = row.cells[row.cells.length - 1];

    
    var cellValue = avgCell.innerText;
    if(cellValue === "F" )
    {
      avgCell.innerText = '0.0';
    }
    else if(cellValue = "D-" )
    {
      avgCell.innerText = '0.7';
    }
    else if(cellValue = "D" )
    {
      avgCell.innerText = '1.0';
    }
    else if(cellValue = "D+" )
    {
      avgCell.innerText = '1.3';
    }
    else if(cellValue = "C-" )
    {
      avgCell.innerText = '1.7';
    }
    else if(cellValue = "C" )
    {
      avgCell.innerText = '2.0';
    }
    else if(cellValue = "C+"  )
    {
      avgCell.innerText = '2.3';
    }
    else if(cellValue = "B-"  )
    {
      avgCell.innerText = '2.7';
    }
    else if(cellValue = "B" )
    {
      avgCell.innerText = '3.0';
    }
    else if(cellValue = "B+"  )
    {
      avgCell.innerText = '3.3';
    }
    else if(cellValue = "A" )
    {
      avgCell.innerText = '3.7';
    }
    else if(cellValue ="A" )
    {
      avgCell.innerText = '4.0';
    }

  }
}


let savedTable;
function saveTable()
{
  savedTable = document.getElementById('myTable').cloneNode(true).innerHTML; //makes a new table memory to save table in current state
}

function restoreTable()
{
  const table = document.getElementById('myTable')
  if (table && savedTable) //changes table to last saved table that was made
    table.innerHTML = savedTable;
}

function addRow() {
  
  var tableBody = document.getElementById("myTable").getElementsByTagName("tbody")[0];

  
  var prevRow = tableBody.rows[tableBody.rows.length - 1];// Get the previous row to make sure its even

  
  var newRow = tableBody.insertRow(-1);// Create a new row after last row

  
  for (let i = 0; i < prevRow.cells.length; i++) {
    const newCell = newRow.insertCell(i); //makes a new cell then adds corret style and funtionality to it
    if(i<2) // if its the first two rows
    {
      newCell.innerHTML = prevRow.cells[i].innerHTML;// Copy the cells from the previous row
    }
    else if(i==prevRow.cells.length-1) // if its the avg row
    {
      newCell.textContent = '0';
      newCell.classList.add("toRight");
      newCell.onclick = function() {
        toggleAverage();
      };
    } 
    else{ //its the assignment rows
      newCell.textContent = '-';
      newCell.classList.add("toMiddle");
      newCell.style.backgroundColor = "yellow";
      newCell.setAttribute('contenteditable', true);
      newCell.addEventListener('input', function()
      {
        changeGrade(newCell);
      })
    }
  }
  getUnsubmitted(); //adds unsubmitted assignments from new row
}

function addColumn() {
  
  const table = document.getElementById("myTable");
  const rows = document.getElementsByTagName( "tr" );
  
  
  for(let i=0; i<rows.length; i++) // loop through columns
  {
    const newCell = rows[i].insertCell(7); // Add a new cell to each row and adds approproate style
    if(i===0)  //if its the hearer row
    {
      newCell.innerHTML = `<strong>Assignment</strong>`;
      newCell.style.textAlign = "center"
      newCell.setAttribute('contenteditable', true);
      newCell.style.color = "aliceblue"
      newCell.style.backgroundColor = "#2e2e2e"
    }
    else{ //then its a data row
      newCell.textContent = '-';
      newCell.classList.add("toMiddle");
      newCell.style.backgroundColor = "yellow";
      newCell.setAttribute('contenteditable', true);
      newCell.addEventListener('input', function()
      {
        changeGrade(newCell);
      })
    }
  }
  getUnsubmitted();  //adds unsubmitted assignments from new row
}

